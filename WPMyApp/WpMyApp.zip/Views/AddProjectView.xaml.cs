﻿using System.Windows.Controls;

namespace WpMyApp.Views
{
    public partial class AddProjectView : UserControl
    {
        public AddProjectView()
        {
            InitializeComponent();
        }
    }
}
