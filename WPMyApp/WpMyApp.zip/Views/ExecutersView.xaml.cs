﻿using System.Windows.Controls;

namespace WpMyApp.Views
{
    public partial class ExecutersView : UserControl
    {
        public ExecutersView()
        {
            InitializeComponent();
        }
    }
}
