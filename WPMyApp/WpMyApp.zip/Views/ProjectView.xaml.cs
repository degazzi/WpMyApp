﻿using System.Windows.Controls;

namespace WpMyApp.Views
{
    public partial class ProjectsView : UserControl
    {
        public ProjectsView()
        {
            InitializeComponent();
        }
    }
}
