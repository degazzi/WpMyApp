﻿using System.Windows.Controls;

namespace WpMyApp.Views
{
    public partial class DeadlinesView : UserControl
    {
        public DeadlinesView()
        {
            InitializeComponent();
        }
    }
}
