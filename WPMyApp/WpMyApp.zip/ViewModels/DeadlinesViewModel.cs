﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace WpMyApp.ViewModels
{
    public partial class DeadlinesViewModel : ObservableObject
    {

    }
}
