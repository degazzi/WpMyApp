﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace WpMyApp.ViewModels
{
    public class DashboardViewModel : ObservableObject { }
}
