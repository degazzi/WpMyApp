﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace WpMyApp.ViewModels
{
    public partial class SettingsViewModel : ObservableObject
    {
        public string Version => "Версия 1.0.0";
    }
}
